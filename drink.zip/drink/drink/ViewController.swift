//
//  ViewController.swift
//  drink
//
//  Created by Oleh Kvasha on 6/30/20.
//  Copyright © 2020 Kvasha Oleh. All rights reserved.
//

import UIKit
import SDWebImage


class ViewController: UIViewController {
    
    @IBOutlet weak var mainTableView: UITableView!

    var drinks : [Drink] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Filters", style: .plain, target: self, action: #selector(addTapped))
        
        self.mainTableView.separatorColor = UIColor.clear
        self.navigationItem.title = "Drinks"

        mainTableView.delegate = self
        mainTableView.dataSource = self
        getData()

    }
    
    @objc func addTapped() {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "FilterViewController") as! FilterViewController
        navigationController?.pushViewController(newViewController, animated: true)
    }
    
    fileprivate func getData() {
        let url = URL(string: "https://www.thecocktaildb.com/api/json/v1/1/filter.php?c=Ordinary_Drink")!
        URLSession.shared.dataTask(with: url) {(data, response, error) in
            do {
                let drinksObject = try JSONDecoder().decode(AllDrinks.self, from: data!)
                self.drinks = drinksObject.drinks!
                
                DispatchQueue.main.async {
                    self.mainTableView.reloadData()
                }
                
                for item in self.drinks {
                    print("name of drink is: \(item.strDrink)")
                    print("picture url of drink is: \(item.strDrinkThumb)")
                }
                
            } catch {
                print("Error! Check your code!")
            }
        }.resume()
    }
}

struct AllDrinks : Decodable {
    let drinks : [Drink]?
}

struct Drink : Decodable {
    let strDrink : String
    let strDrinkThumb : String
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return drinks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = mainTableView.dequeueReusableCell(withIdentifier: "MainCell", for: indexPath) as! MainTableViewCell
        let item = drinks[indexPath.row]
        guard let url = URL(string: item.strDrinkThumb) else { return cell }
        cell.mainImage.sd_setImage(with: url, completed: nil)
        cell.mainTitle.text = item.strDrink
        cell.selectionStyle = UITableViewCell.SelectionStyle.none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return view.frame.height / 5
    }
}


