//
//  FilterViewController.swift
//  drink
//
//  Created by Oleh Kvasha on 7/2/20.
//  Copyright © 2020 Kvasha Oleh. All rights reserved.
//

import UIKit

class FilterViewController: UIViewController {

    @IBOutlet weak var filterTableView: UITableView!
    
    var category : [DrinkCategory] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.filterTableView.separatorColor = UIColor.clear
        self.navigationItem.title = "Filters"

        
        filterTableView.delegate = self
        filterTableView.dataSource = self
        getData()

    }
    
    fileprivate func getData() {
        let url = URL(string: "https://www.thecocktaildb.com/api/json/v1/1/list.php?c=list")!
        URLSession.shared.dataTask(with: url) {(data, response, error) in
            do {
                let drinksObject = try JSONDecoder().decode(AllCategoryOfDrinks.self, from: data!)
                self.category = drinksObject.drinks!
                
                DispatchQueue.main.async {
                    self.filterTableView.reloadData()
                }
                
            } catch {
                print("Error! Check your code!")
            }
            }.resume()
    }


}

struct AllCategoryOfDrinks : Decodable {
    let drinks : [DrinkCategory]?
}

struct DrinkCategory : Decodable {
    let strCategory : String
}


extension FilterViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return category.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = filterTableView.dequeueReusableCell(withIdentifier: "FilterCell", for: indexPath) as! FilterTableViewCell
        let item = category[indexPath.row]
        cell.filterName.text = item.strCategory
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return view.frame.height / 9
    }
    
    
    
    
}
